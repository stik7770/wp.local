# WordPress MySQL database migration
#
# Generated: Thursday 7. July 2022 06:01 UTC
# Hostname: localhost
# Database: `db-wp`
# URL: //localhost/wp.local
# Path: \\\\EDU.LOCAL\\PUBLIC\\studenthomes\\20300675\\My Documents\\uwamp\\www\\wp.local
# Tables: wp_commentmeta, wp_comments, wp_links, wp_options, wp_postmeta, wp_posts, wp_term_relationships, wp_term_taxonomy, wp_termmeta, wp_terms, wp_usermeta, wp_users
# Table Prefix: wp_
# Post Types: revision, attachment, customize_changeset, page, post, wp_global_styles
# Protocol: http
# Multisite: false
# Subsite Export: false
# --------------------------------------------------------

/*!40101 SET NAMES utf8mb4 */;

SET sql_mode='NO_AUTO_VALUE_ON_ZERO';



#
# Delete any existing table `wp_commentmeta`
#

DROP TABLE IF EXISTS `wp_commentmeta`;


#
# Table structure of table `wp_commentmeta`
#

CREATE TABLE `wp_commentmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `comment_id` (`comment_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_commentmeta`
#

#
# End of data contents of table `wp_commentmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_comments`
#

DROP TABLE IF EXISTS `wp_comments`;


#
# Table structure of table `wp_comments`
#

CREATE TABLE `wp_comments` (
  `comment_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_post_ID` bigint(20) unsigned NOT NULL DEFAULT '0',
  `comment_author` tinytext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `comment_author_email` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_type` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'comment',
  `comment_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`comment_ID`),
  KEY `comment_post_ID` (`comment_post_ID`),
  KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  KEY `comment_date_gmt` (`comment_date_gmt`),
  KEY `comment_parent` (`comment_parent`),
  KEY `comment_author_email` (`comment_author_email`(10))
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_comments`
#
INSERT INTO `wp_comments` ( `comment_ID`, `comment_post_ID`, `comment_author`, `comment_author_email`, `comment_author_url`, `comment_author_IP`, `comment_date`, `comment_date_gmt`, `comment_content`, `comment_karma`, `comment_approved`, `comment_agent`, `comment_type`, `comment_parent`, `user_id`) VALUES
(1, 1, 'Комментатор WordPress', 'wapuu@wordpress.example', 'https://ru.wordpress.org/', '', '2022-07-06 08:52:02', '2022-07-06 05:52:02', 'Привет! Это комментарий.\nЧтобы начать модерировать, редактировать и удалять комментарии, перейдите на экран «Комментарии» в консоли.\nАватары авторов комментариев загружаются с сервиса <a href="https://ru.gravatar.com/">Gravatar</a>.', 0, '1', '', 'comment', 0, 0),
(2, 1, 'admin', '20300675@live.inueco.ru', 'http://localhost/wp.local', '::1', '2022-07-06 09:24:17', '2022-07-06 06:24:17', 'Welcome', 0, '1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.0.0 Safari/537.36', 'comment', 0, 1) ;

#
# End of data contents of table `wp_comments`
# --------------------------------------------------------



#
# Delete any existing table `wp_links`
#

DROP TABLE IF EXISTS `wp_links`;


#
# Table structure of table `wp_links`
#

CREATE TABLE `wp_links` (
  `link_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `link_url` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_name` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_image` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_target` varchar(25) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_description` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_visible` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) unsigned NOT NULL DEFAULT '1',
  `link_rating` int(11) NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `link_notes` mediumtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `link_rss` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`link_id`),
  KEY `link_visible` (`link_visible`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_links`
#

#
# End of data contents of table `wp_links`
# --------------------------------------------------------



#
# Delete any existing table `wp_options`
#

DROP TABLE IF EXISTS `wp_options`;


#
# Table structure of table `wp_options`
#

CREATE TABLE `wp_options` (
  `option_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(191) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `option_value` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `autoload` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`option_id`),
  UNIQUE KEY `option_name` (`option_name`),
  KEY `autoload` (`autoload`)
) ENGINE=InnoDB AUTO_INCREMENT=389 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_options`
#
INSERT INTO `wp_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(1, 'siteurl', 'http://localhost/wp.local', 'yes'),
(2, 'home', 'http://localhost/wp.local', 'yes'),
(3, 'blogname', 'BushWick', 'yes'),
(4, 'blogdescription', 'Magazin prodazhi chasov ', 'yes'),
(5, 'users_can_register', '0', 'yes'),
(6, 'admin_email', '20300675@live.inueco.ru', 'yes'),
(7, 'start_of_week', '1', 'yes'),
(8, 'use_balanceTags', '0', 'yes'),
(9, 'use_smilies', '1', 'yes'),
(10, 'require_name_email', '1', 'yes'),
(11, 'comments_notify', '1', 'yes'),
(12, 'posts_per_rss', '10', 'yes'),
(13, 'rss_use_excerpt', '0', 'yes'),
(14, 'mailserver_url', 'mail.example.com', 'yes'),
(15, 'mailserver_login', 'login@example.com', 'yes'),
(16, 'mailserver_pass', 'password', 'yes'),
(17, 'mailserver_port', '110', 'yes'),
(18, 'default_category', '1', 'yes'),
(19, 'default_comment_status', 'open', 'yes'),
(20, 'default_ping_status', 'open', 'yes'),
(21, 'default_pingback_flag', '1', 'yes'),
(22, 'posts_per_page', '10', 'yes'),
(23, 'date_format', 'd.m.Y', 'yes'),
(24, 'time_format', 'H:i', 'yes'),
(25, 'links_updated_date_format', 'd.m.Y H:i', 'yes'),
(26, 'comment_moderation', '0', 'yes'),
(27, 'moderation_notify', '1', 'yes'),
(28, 'permalink_structure', '', 'yes'),
(29, 'rewrite_rules', '', 'yes'),
(30, 'hack_file', '0', 'yes'),
(31, 'blog_charset', 'UTF-8', 'yes'),
(32, 'moderation_keys', '', 'no'),
(33, 'active_plugins', 'a:1:{i:0;s:31:"wp-migrate-db/wp-migrate-db.php";}', 'yes'),
(34, 'category_base', '', 'yes'),
(35, 'ping_sites', 'http://rpc.pingomatic.com/', 'yes'),
(36, 'comment_max_links', '2', 'yes'),
(37, 'gmt_offset', '3', 'yes'),
(38, 'default_email_category', '1', 'yes'),
(39, 'recently_edited', '', 'no'),
(40, 'template', 'goldly', 'yes'),
(41, 'stylesheet', 'ecommerce-goldly', 'yes'),
(42, 'comment_registration', '0', 'yes'),
(43, 'html_type', 'text/html', 'yes'),
(44, 'use_trackback', '0', 'yes'),
(45, 'default_role', 'subscriber', 'yes'),
(46, 'db_version', '51917', 'yes'),
(47, 'uploads_use_yearmonth_folders', '1', 'yes'),
(48, 'upload_path', '', 'yes'),
(49, 'blog_public', '1', 'yes'),
(50, 'default_link_category', '2', 'yes'),
(51, 'show_on_front', 'posts', 'yes'),
(52, 'tag_base', '', 'yes'),
(53, 'show_avatars', '1', 'yes'),
(54, 'avatar_rating', 'G', 'yes'),
(55, 'upload_url_path', '', 'yes'),
(56, 'thumbnail_size_w', '150', 'yes'),
(57, 'thumbnail_size_h', '150', 'yes'),
(58, 'thumbnail_crop', '1', 'yes'),
(59, 'medium_size_w', '300', 'yes'),
(60, 'medium_size_h', '300', 'yes'),
(61, 'avatar_default', 'mystery', 'yes'),
(62, 'large_size_w', '1024', 'yes'),
(63, 'large_size_h', '1024', 'yes'),
(64, 'image_default_link_type', 'none', 'yes'),
(65, 'image_default_size', '', 'yes'),
(66, 'image_default_align', '', 'yes'),
(67, 'close_comments_for_old_posts', '0', 'yes'),
(68, 'close_comments_days_old', '14', 'yes'),
(69, 'thread_comments', '1', 'yes'),
(70, 'thread_comments_depth', '5', 'yes'),
(71, 'page_comments', '0', 'yes'),
(72, 'comments_per_page', '50', 'yes'),
(73, 'default_comments_page', 'newest', 'yes'),
(74, 'comment_order', 'asc', 'yes'),
(75, 'sticky_posts', 'a:0:{}', 'yes'),
(76, 'widget_categories', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes'),
(77, 'widget_text', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes'),
(78, 'widget_rss', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes'),
(79, 'uninstall_plugins', 'a:0:{}', 'no'),
(80, 'timezone_string', '', 'yes'),
(81, 'page_for_posts', '0', 'yes'),
(82, 'page_on_front', '0', 'yes'),
(83, 'default_post_format', '0', 'yes'),
(84, 'link_manager_enabled', '0', 'yes'),
(85, 'finished_splitting_shared_terms', '1', 'yes'),
(86, 'site_icon', '0', 'yes'),
(87, 'medium_large_size_w', '768', 'yes'),
(88, 'medium_large_size_h', '0', 'yes'),
(89, 'wp_page_for_privacy_policy', '3', 'yes'),
(90, 'show_comments_cookies_opt_in', '1', 'yes'),
(91, 'admin_email_lifespan', '1672638721', 'yes'),
(92, 'disallowed_keys', '', 'no'),
(93, 'comment_previously_approved', '1', 'yes'),
(94, 'auto_plugin_theme_update_emails', 'a:0:{}', 'no'),
(95, 'auto_update_core_dev', 'enabled', 'yes'),
(96, 'auto_update_core_minor', 'enabled', 'yes'),
(97, 'auto_update_core_major', 'enabled', 'yes'),
(98, 'wp_force_deactivated_plugins', 'a:0:{}', 'yes'),
(99, 'initial_db_version', '51917', 'yes'),
(100, 'wp_user_roles', 'a:5:{s:13:"administrator";a:2:{s:4:"name";s:13:"Administrator";s:12:"capabilities";a:61:{s:13:"switch_themes";b:1;s:11:"edit_themes";b:1;s:16:"activate_plugins";b:1;s:12:"edit_plugins";b:1;s:10:"edit_users";b:1;s:10:"edit_files";b:1;s:14:"manage_options";b:1;s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:6:"import";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:8:"level_10";b:1;s:7:"level_9";b:1;s:7:"level_8";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:12:"delete_users";b:1;s:12:"create_users";b:1;s:17:"unfiltered_upload";b:1;s:14:"edit_dashboard";b:1;s:14:"update_plugins";b:1;s:14:"delete_plugins";b:1;s:15:"install_plugins";b:1;s:13:"update_themes";b:1;s:14:"install_themes";b:1;s:11:"update_core";b:1;s:10:"list_users";b:1;s:12:"remove_users";b:1;s:13:"promote_users";b:1;s:18:"edit_theme_options";b:1;s:13:"delete_themes";b:1;s:6:"export";b:1;}}s:6:"editor";a:2:{s:4:"name";s:6:"Editor";s:12:"capabilities";a:34:{s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;}}s:6:"author";a:2:{s:4:"name";s:6:"Author";s:12:"capabilities";a:10:{s:12:"upload_files";b:1;s:10:"edit_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:4:"read";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;s:22:"delete_published_posts";b:1;}}s:11:"contributor";a:2:{s:4:"name";s:11:"Contributor";s:12:"capabilities";a:5:{s:10:"edit_posts";b:1;s:4:"read";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;}}s:10:"subscriber";a:2:{s:4:"name";s:10:"Subscriber";s:12:"capabilities";a:2:{s:4:"read";b:1;s:7:"level_0";b:1;}}}', 'yes') ;
INSERT INTO `wp_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(101, 'fresh_site', '0', 'yes'),
(102, 'WPLANG', 'ru_RU', 'yes'),
(103, 'user_count', '1', 'no'),
(104, 'widget_block', 'a:7:{i:2;a:1:{s:7:"content";s:19:"<!-- wp:search /-->";}i:3;a:1:{s:7:"content";s:154:"<!-- wp:group -->\n<div class="wp-block-group"><!-- wp:heading -->\n<h2>Свежие записи<br><br></h2>\n<!-- /wp:heading --></div>\n<!-- /wp:group -->";}i:4;a:1:{s:7:"content";s:164:"<!-- wp:group -->\n<div class="wp-block-group"><!-- wp:heading -->\n<h2>Свежие комментарии<br><br></h2>\n<!-- /wp:heading --></div>\n<!-- /wp:group -->";}i:5;a:1:{s:7:"content";s:141:"<!-- wp:group -->\n<div class="wp-block-group"><!-- wp:heading -->\n<h2>Архивы<br><br></h2>\n<!-- /wp:heading --></div>\n<!-- /wp:group -->";}i:6;a:1:{s:7:"content";s:143:"<!-- wp:group -->\n<div class="wp-block-group"><!-- wp:heading -->\n<h2>Рубрики<br><br></h2>\n<!-- /wp:heading --></div>\n<!-- /wp:group -->";}s:12:"_multiwidget";i:1;i:9;a:1:{s:7:"content";s:146:"<!-- wp:gallery {"linkTo":"none"} -->\n<figure class="wp-block-gallery has-nested-images columns-default is-cropped"></figure>\n<!-- /wp:gallery -->";}}', 'yes'),
(105, 'sidebars_widgets', 'a:9:{s:19:"wp_inactive_widgets";a:0:{}s:7:"section";a:0:{}s:9:"sidebar-1";a:5:{i:0;s:7:"block-2";i:1;s:7:"block-3";i:2;s:7:"block-4";i:3;s:7:"block-5";i:4;s:7:"block-6";}s:7:"footer1";a:1:{i:0;s:7:"block-9";}s:7:"footer2";a:0:{}s:7:"footer3";a:0:{}s:7:"footer4";a:0:{}s:7:"footer5";a:0:{}s:13:"array_version";i:3;}', 'yes'),
(106, 'cron', 'a:8:{i:1657175231;a:1:{s:30:"wp_scheduled_auto_draft_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1657176742;a:1:{s:34:"wp_privacy_delete_old_export_files";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:6:"hourly";s:4:"args";a:0:{}s:8:"interval";i:3600;}}}i:1657216342;a:4:{s:18:"wp_https_detection";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:16:"wp_version_check";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:17:"wp_update_plugins";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:16:"wp_update_themes";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1657216437;a:1:{s:21:"wp_update_user_counts";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1657259541;a:1:{s:32:"recovery_mode_clean_expired_keys";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1657259990;a:2:{s:19:"wp_scheduled_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}s:25:"delete_expired_transients";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1657777941;a:1:{s:30:"wp_site_health_scheduled_check";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:6:"weekly";s:4:"args";a:0:{}s:8:"interval";i:604800;}}}s:7:"version";i:2;}', 'yes'),
(107, 'widget_pages', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(108, 'widget_calendar', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(109, 'widget_archives', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(110, 'widget_media_audio', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(111, 'widget_media_image', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(112, 'widget_media_gallery', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(113, 'widget_media_video', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(114, 'widget_meta', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(115, 'widget_search', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(116, 'widget_tag_cloud', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(117, 'widget_nav_menu', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(118, 'widget_custom_html', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(122, 'recovery_keys', 'a:0:{}', 'yes'),
(125, 'theme_mods_twentytwentytwo', 'a:2:{s:18:"custom_css_post_id";i:-1;s:16:"sidebars_widgets";a:2:{s:4:"time";i:1657093144;s:4:"data";a:3:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:3:{i:0;s:7:"block-2";i:1;s:7:"block-3";i:2;s:7:"block-4";}s:9:"sidebar-2";a:2:{i:0;s:7:"block-5";i:1;s:7:"block-6";}}}}', 'yes'),
(128, 'https_detection_errors', 'a:1:{s:23:"ssl_verification_failed";a:1:{i:0;s:38:"Проверка SSL неудачна.";}}', 'yes'),
(148, 'can_compress_scripts', '1', 'no'),
(164, 'finished_updating_comment_type', '1', 'yes'),
(187, 'wp_calendar_block_has_published_posts', '1', 'yes'),
(206, 'current_theme', 'Ecommerce Goldly', 'yes'),
(207, 'theme_mods_ecommerce-goldly', 'a:84:{i:0;b:0;s:21:"goldly_excerpt_length";s:2:"50";s:22:"goldly_sticky_bg_color";s:4:"#333";s:22:"goldly_button_bg_color";s:4:"#333";s:29:"goldly_button_texthover_color";s:4:"#333";s:26:"goldly_button_border_color";s:4:"#333";s:29:"goldly_scroll_button_bg_color";s:7:"#000000";s:31:"goldly_sidebar_heading_bg_color";s:4:"#333";s:22:"goldly_footer_bg_color";s:4:"#333";s:28:"goldly_breadcrumb_text_color";s:7:"#ffffff";s:28:"goldly_breadcrumb_link_color";s:7:"#85e2dc";s:30:"featured_slider_arrow_bg_color";s:7:"#333333";s:37:"featured_slider_arrow_texthover_color";s:7:"#333333";s:29:"goldly_featured_section_color";s:7:"#333333";s:38:"goldly_featured_section_bg_hover_color";s:7:"#333333";s:29:"our_team_container_text_color";s:7:"#333333";s:28:"our_team_icon_bg_hover_color";s:7:"#333333";s:31:"our_team_testimonial_text_color";s:7:"#333333";s:31:"our_services_contain_text_color";s:7:"#333333";s:37:"our_services_contain_text_hover_color";s:7:"#333333";s:31:"our_services_border_hover_color";s:7:"#333333";s:17:"goldly_link_color";s:7:"#000000";s:24:"goldly_topbar_text_color";s:7:"#333333";s:30:"goldly_header_background_color";s:7:"#333333";s:27:"goldly_social_icon_bg_color";s:7:"#273641";s:30:"goldly_social_icon_hover_color";s:7:"#214462";s:33:"goldly_social_icon_bg_hover_color";s:7:"#a5a5a5";s:33:"goldly_callmenu_btn_bghover_color";s:7:"#333333";s:25:"goldly_callmenu_btn_color";s:7:"#333333";s:28:"goldly_call_btn_border_color";s:7:"#333333";s:30:"goldly_mobile_navmenu_bg_color";s:7:"#273641";s:30:"goldly_mobile_submenu_bg_color";s:7:"#adabab";s:23:"goldly_submenu_bg_color";s:7:"#adabab";s:26:"goldly_breadcrumb_bg_color";s:7:"#c8c9cb";s:20:"goldly_header_layout";s:7:"header4";s:24:"goldly_footer_text_color";s:7:"#85e2dc";s:23:"our_sponsors_main_title";s:9:"Our Brand";s:24:"our_portfolio_main_title";s:28:"Best Selling Off The Week...";s:19:"our_team_main_title";s:21:"Something New For You";s:29:"design_heding_underline_color";s:7:"#333333";s:42:"goldly_transparent_header_link_hover_color";s:7:"#b5b5b5";s:18:"nav_menu_locations";a:0:{}s:18:"custom_css_post_id";i:-1;s:26:"goldly_contact_info_number";s:16:"+7-904-306-92-32";s:24:"goldly_email_info_number";s:23:"20300513@live.inueco.ru";s:19:"goldly_twitter_link";s:20:"https://twitter.com/";s:20:"goldly_facebook_link";s:25:"https://www.facebook.com/";s:36:"goldly_transparent_header_text_color";s:7:"#ffffff";s:26:"goldly_call_menu_btn_title";s:22:"Регистрация";s:22:"goldly_body_fontfamily";s:1:"1";s:26:"goldly_Heading1_fontfamily";s:1:"1";s:26:"goldly_Heading2_fontfamily";s:1:"1";s:26:"goldly_Heading3_fontfamily";s:1:"1";s:24:"featuredimage_slider_tab";s:7:"general";s:19:"about_title_section";s:9:"О нас";s:20:"featured_section_tab";s:7:"general";s:12:"header_image";s:13:"remove-header";s:16:"background_image";s:0:"";s:11:"custom_logo";s:0:"";s:26:"goldly_breadcrumb_bg_image";s:0:"";s:24:"featured_image_sliders_1";s:86:"http://localhost/wp.local/wp-content/uploads/2022/07/Baner-v-Galereyu-KOSMOS_MOB-6.jpg";s:24:"featured_image_sliders_2";s:97:"http://localhost/wp.local/wp-content/uploads/2022/07/d3Ycun8SIRM1VGiTHNMlGK8JSxPf5fnUzBsh3lR6.jpg";s:19:"about_image_sliders";s:86:"http://localhost/wp.local/wp-content/uploads/2022/07/Baner-v-Galereyu-KOSMOS_MOB-5.jpg";s:21:"our_portfolio_image_1";s:97:"http://localhost/wp.local/wp-content/uploads/2022/07/d3Ycun8SIRM1VGiTHNMlGK8JSxPf5fnUzBsh3lR6.jpg";s:21:"our_portfolio_image_2";s:97:"http://localhost/wp.local/wp-content/uploads/2022/07/d3Ycun8SIRM1VGiTHNMlGK8JSxPf5fnUzBsh3lR6.jpg";s:21:"our_portfolio_image_3";s:97:"http://localhost/wp.local/wp-content/uploads/2022/07/d3Ycun8SIRM1VGiTHNMlGK8JSxPf5fnUzBsh3lR6.jpg";s:15:"our_team_image1";s:96:"http://localhost/wp.local/wp-content/uploads/2022/07/OS0002_1140x400Px_for_Chelyabinsk_nov21.jpg";s:15:"our_team_image2";s:96:"http://localhost/wp.local/wp-content/uploads/2022/07/OS0002_1140x400Px_for_Chelyabinsk_nov21.jpg";s:15:"our_team_image3";s:96:"http://localhost/wp.local/wp-content/uploads/2022/07/OS0002_1140x400Px_for_Chelyabinsk_nov21.jpg";s:15:"our_team_image4";s:96:"http://localhost/wp.local/wp-content/uploads/2022/07/OS0002_1140x400Px_for_Chelyabinsk_nov21.jpg";s:23:"our_testimonial_image_1";s:94:"http://localhost/wp.local/wp-content/uploads/2022/07/cropped-Baner-v-Galereyu-KOSMOS_MOB-4.jpg";s:23:"our_testimonial_image_3";s:96:"http://localhost/wp.local/wp-content/uploads/2022/07/OS0002_1140x400Px_for_Chelyabinsk_nov21.jpg";s:23:"our_testimonial_image_2";s:84:"http://localhost/wp.local/wp-content/uploads/2022/07/scrollable_banner_image_two.jpg";s:20:"our_services_title_4";s:22:"вправправрп";s:25:"our_services_title_link_4";s:1:"#";s:26:"our_services_description_4";s:20:"кепавпавпр";s:20:"our_sponsors_image_1";s:60:"http://localhost/wp.local/wp-content/uploads/2022/07/ц1.png";s:20:"our_sponsors_image_2";s:60:"http://localhost/wp.local/wp-content/uploads/2022/07/ц3.jpg";s:20:"our_sponsors_image_3";s:60:"http://localhost/wp.local/wp-content/uploads/2022/07/ц4.png";s:20:"our_sponsors_image_4";s:60:"http://localhost/wp.local/wp-content/uploads/2022/07/ц5.jpg";s:20:"our_sponsors_image_5";s:60:"http://localhost/wp.local/wp-content/uploads/2022/07/ц6.jpg";s:14:"goldly_diseble";s:27:"Goldly_our_services_section";s:18:"features_one_icon1";s:10:"fa fa-user";s:25:"goldly_Heading_fontfamily";s:1:"1";}', 'yes'),
(208, 'theme_switched', '', 'yes'),
(210, 'widget_recent-comments', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes'),
(211, 'widget_recent-posts', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes'),
(360, 'recently_activated', 'a:0:{}', 'yes'),
(374, 'goldly_hide_msg', '1', 'yes'),
(388, 'wpmdb_usage', 'a:2:{s:6:"action";s:8:"savefile";s:4:"time";i:1657173690;}', 'no') ;

#
# End of data contents of table `wp_options`
# --------------------------------------------------------



#
# Delete any existing table `wp_postmeta`
#

DROP TABLE IF EXISTS `wp_postmeta`;


#
# Table structure of table `wp_postmeta`
#

CREATE TABLE `wp_postmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=66 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_postmeta`
#
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(1, 2, '_wp_page_template', 'default'),
(2, 3, '_wp_page_template', 'default'),
(3, 1, '_edit_lock', '1657088626:1'),
(4, 7, '_wp_attached_file', '2022/07/avatar.jpg'),
(5, 7, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:500;s:6:"height";i:500;s:4:"file";s:18:"2022/07/avatar.jpg";s:8:"filesize";i:5988;s:5:"sizes";a:2:{s:6:"medium";a:5:{s:4:"file";s:18:"avatar-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:3898;}s:9:"thumbnail";a:5:{s:4:"file";s:18:"avatar-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:1943;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(6, 8, '_wp_attached_file', '2022/07/avatar-1.jpg'),
(7, 8, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:500;s:6:"height";i:500;s:4:"file";s:20:"2022/07/avatar-1.jpg";s:8:"filesize";i:5988;s:5:"sizes";a:2:{s:6:"medium";a:5:{s:4:"file";s:20:"avatar-1-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:3898;}s:9:"thumbnail";a:5:{s:4:"file";s:20:"avatar-1-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:1943;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(10, 10, '_edit_lock', '1657091906:1'),
(15, 13, '_edit_lock', '1657093645:1'),
(16, 13, '_wp_trash_meta_status', 'publish'),
(17, 13, '_wp_trash_meta_time', '1657093693'),
(18, 14, '_edit_lock', '1657095582:1'),
(19, 15, '_wp_attached_file', '2022/07/Baner-v-Galereyu-KOSMOS_MOB.jpg'),
(20, 15, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:960;s:6:"height";i:960;s:4:"file";s:39:"2022/07/Baner-v-Galereyu-KOSMOS_MOB.jpg";s:8:"filesize";i:143310;s:5:"sizes";a:4:{s:6:"medium";a:5:{s:4:"file";s:39:"Baner-v-Galereyu-KOSMOS_MOB-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:20222;}s:9:"thumbnail";a:5:{s:4:"file";s:39:"Baner-v-Galereyu-KOSMOS_MOB-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:6928;}s:12:"medium_large";a:5:{s:4:"file";s:39:"Baner-v-Galereyu-KOSMOS_MOB-768x768.jpg";s:5:"width";i:768;s:6:"height";i:768;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:87623;}s:14:"post-thumbnail";a:5:{s:4:"file";s:39:"Baner-v-Galereyu-KOSMOS_MOB-600x350.jpg";s:5:"width";i:600;s:6:"height";i:350;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:39846;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(21, 16, '_wp_attached_file', '2022/07/cropped-Baner-v-Galereyu-KOSMOS_MOB.jpg'),
(22, 16, '_wp_attachment_context', 'custom-header'),
(23, 16, '_wp_attachment_metadata', 'a:7:{s:5:"width";i:1000;s:6:"height";i:250;s:4:"file";s:47:"2022/07/cropped-Baner-v-Galereyu-KOSMOS_MOB.jpg";s:8:"filesize";i:37129;s:5:"sizes";a:4:{s:6:"medium";a:5:{s:4:"file";s:46:"cropped-Baner-v-Galereyu-KOSMOS_MOB-300x75.jpg";s:5:"width";i:300;s:6:"height";i:75;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:6072;}s:9:"thumbnail";a:5:{s:4:"file";s:47:"cropped-Baner-v-Galereyu-KOSMOS_MOB-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:5617;}s:12:"medium_large";a:5:{s:4:"file";s:47:"cropped-Baner-v-Galereyu-KOSMOS_MOB-768x192.jpg";s:5:"width";i:768;s:6:"height";i:192;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:23101;}s:14:"post-thumbnail";a:5:{s:4:"file";s:47:"cropped-Baner-v-Galereyu-KOSMOS_MOB-600x250.jpg";s:5:"width";i:600;s:6:"height";i:250;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:29052;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}s:17:"attachment_parent";i:15;}'),
(26, 17, '_wp_attached_file', '2022/07/Baner-v-Galereyu-KOSMOS_MOB-1.jpg'),
(27, 17, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:960;s:6:"height";i:960;s:4:"file";s:41:"2022/07/Baner-v-Galereyu-KOSMOS_MOB-1.jpg";s:8:"filesize";i:143310;s:5:"sizes";a:4:{s:6:"medium";a:5:{s:4:"file";s:41:"Baner-v-Galereyu-KOSMOS_MOB-1-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:20222;}s:9:"thumbnail";a:5:{s:4:"file";s:41:"Baner-v-Galereyu-KOSMOS_MOB-1-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:6928;}s:12:"medium_large";a:5:{s:4:"file";s:41:"Baner-v-Galereyu-KOSMOS_MOB-1-768x768.jpg";s:5:"width";i:768;s:6:"height";i:768;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:87623;}s:14:"post-thumbnail";a:5:{s:4:"file";s:41:"Baner-v-Galereyu-KOSMOS_MOB-1-600x350.jpg";s:5:"width";i:600;s:6:"height";i:350;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:39846;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(28, 18, '_wp_attached_file', '2022/07/Baner-v-Galereyu-KOSMOS_MOB-2.jpg'),
(29, 18, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:960;s:6:"height";i:960;s:4:"file";s:41:"2022/07/Baner-v-Galereyu-KOSMOS_MOB-2.jpg";s:8:"filesize";i:143310;s:5:"sizes";a:4:{s:6:"medium";a:5:{s:4:"file";s:41:"Baner-v-Galereyu-KOSMOS_MOB-2-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:20222;}s:9:"thumbnail";a:5:{s:4:"file";s:41:"Baner-v-Galereyu-KOSMOS_MOB-2-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:6928;}s:12:"medium_large";a:5:{s:4:"file";s:41:"Baner-v-Galereyu-KOSMOS_MOB-2-768x768.jpg";s:5:"width";i:768;s:6:"height";i:768;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:87623;}s:14:"post-thumbnail";a:5:{s:4:"file";s:41:"Baner-v-Galereyu-KOSMOS_MOB-2-600x350.jpg";s:5:"width";i:600;s:6:"height";i:350;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:39846;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(30, 19, '_wp_attached_file', '2022/07/Baner-v-Galereyu-KOSMOS_MOB-3.jpg'),
(31, 19, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:960;s:6:"height";i:960;s:4:"file";s:41:"2022/07/Baner-v-Galereyu-KOSMOS_MOB-3.jpg";s:8:"filesize";i:143310;s:5:"sizes";a:4:{s:6:"medium";a:5:{s:4:"file";s:41:"Baner-v-Galereyu-KOSMOS_MOB-3-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:20222;}s:9:"thumbnail";a:5:{s:4:"file";s:41:"Baner-v-Galereyu-KOSMOS_MOB-3-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:6928;}s:12:"medium_large";a:5:{s:4:"file";s:41:"Baner-v-Galereyu-KOSMOS_MOB-3-768x768.jpg";s:5:"width";i:768;s:6:"height";i:768;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:87623;}s:14:"post-thumbnail";a:5:{s:4:"file";s:41:"Baner-v-Galereyu-KOSMOS_MOB-3-600x350.jpg";s:5:"width";i:600;s:6:"height";i:350;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:39846;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(32, 20, '_wp_attached_file', '2022/07/Baner-v-Galereyu-KOSMOS_MOB-4.jpg'),
(33, 20, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:960;s:6:"height";i:960;s:4:"file";s:41:"2022/07/Baner-v-Galereyu-KOSMOS_MOB-4.jpg";s:8:"filesize";i:143310;s:5:"sizes";a:4:{s:6:"medium";a:5:{s:4:"file";s:41:"Baner-v-Galereyu-KOSMOS_MOB-4-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:20222;}s:9:"thumbnail";a:5:{s:4:"file";s:41:"Baner-v-Galereyu-KOSMOS_MOB-4-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:6928;}s:12:"medium_large";a:5:{s:4:"file";s:41:"Baner-v-Galereyu-KOSMOS_MOB-4-768x768.jpg";s:5:"width";i:768;s:6:"height";i:768;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:87623;}s:14:"post-thumbnail";a:5:{s:4:"file";s:41:"Baner-v-Galereyu-KOSMOS_MOB-4-600x350.jpg";s:5:"width";i:600;s:6:"height";i:350;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:39846;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(34, 21, '_wp_attached_file', '2022/07/Baner-v-Galereyu-KOSMOS_MOB-5.jpg'),
(35, 21, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:960;s:6:"height";i:960;s:4:"file";s:41:"2022/07/Baner-v-Galereyu-KOSMOS_MOB-5.jpg";s:8:"filesize";i:143310;s:5:"sizes";a:4:{s:6:"medium";a:5:{s:4:"file";s:41:"Baner-v-Galereyu-KOSMOS_MOB-5-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:20222;}s:9:"thumbnail";a:5:{s:4:"file";s:41:"Baner-v-Galereyu-KOSMOS_MOB-5-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:6928;}s:12:"medium_large";a:5:{s:4:"file";s:41:"Baner-v-Galereyu-KOSMOS_MOB-5-768x768.jpg";s:5:"width";i:768;s:6:"height";i:768;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:87623;}s:14:"post-thumbnail";a:5:{s:4:"file";s:41:"Baner-v-Galereyu-KOSMOS_MOB-5-600x350.jpg";s:5:"width";i:600;s:6:"height";i:350;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:39846;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(36, 22, '_wp_attached_file', '2022/07/Baner-v-Galereyu-KOSMOS_MOB-6.jpg'),
(37, 22, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:960;s:6:"height";i:960;s:4:"file";s:41:"2022/07/Baner-v-Galereyu-KOSMOS_MOB-6.jpg";s:8:"filesize";i:143310;s:5:"sizes";a:4:{s:6:"medium";a:5:{s:4:"file";s:41:"Baner-v-Galereyu-KOSMOS_MOB-6-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:20222;}s:9:"thumbnail";a:5:{s:4:"file";s:41:"Baner-v-Galereyu-KOSMOS_MOB-6-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:6928;}s:12:"medium_large";a:5:{s:4:"file";s:41:"Baner-v-Galereyu-KOSMOS_MOB-6-768x768.jpg";s:5:"width";i:768;s:6:"height";i:768;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:87623;}s:14:"post-thumbnail";a:5:{s:4:"file";s:41:"Baner-v-Galereyu-KOSMOS_MOB-6-600x350.jpg";s:5:"width";i:600;s:6:"height";i:350;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:39846;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(38, 18, '_wp_attachment_is_custom_background', 'ecommerce-goldly'),
(41, 23, '_wp_attached_file', '2022/07/cropped-Baner-v-Galereyu-KOSMOS_MOB-4.jpg'),
(42, 23, '_wp_attachment_context', 'site-icon'),
(43, 23, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:512;s:6:"height";i:512;s:4:"file";s:49:"2022/07/cropped-Baner-v-Galereyu-KOSMOS_MOB-4.jpg";s:8:"filesize";i:46826;s:5:"sizes";a:7:{s:6:"medium";a:5:{s:4:"file";s:49:"cropped-Baner-v-Galereyu-KOSMOS_MOB-4-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:19318;}s:9:"thumbnail";a:5:{s:4:"file";s:49:"cropped-Baner-v-Galereyu-KOSMOS_MOB-4-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:6801;}s:14:"post-thumbnail";a:5:{s:4:"file";s:49:"cropped-Baner-v-Galereyu-KOSMOS_MOB-4-512x350.jpg";s:5:"width";i:512;s:6:"height";i:350;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:36338;}s:13:"site_icon-270";a:5:{s:4:"file";s:49:"cropped-Baner-v-Galereyu-KOSMOS_MOB-4-270x270.jpg";s:5:"width";i:270;s:6:"height";i:270;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:16369;}s:13:"site_icon-192";a:5:{s:4:"file";s:49:"cropped-Baner-v-Galereyu-KOSMOS_MOB-4-192x192.jpg";s:5:"width";i:192;s:6:"height";i:192;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:9696;}s:13:"site_icon-180";a:5:{s:4:"file";s:49:"cropped-Baner-v-Galereyu-KOSMOS_MOB-4-180x180.jpg";s:5:"width";i:180;s:6:"height";i:180;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:8939;}s:12:"site_icon-32";a:5:{s:4:"file";s:47:"cropped-Baner-v-Galereyu-KOSMOS_MOB-4-32x32.jpg";s:5:"width";i:32;s:6:"height";i:32;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:1168;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(44, 24, '_wp_attached_file', '2022/07/OS0002_1140x400Px_for_Chelyabinsk_nov21.jpg'),
(45, 24, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:1140;s:6:"height";i:400;s:4:"file";s:51:"2022/07/OS0002_1140x400Px_for_Chelyabinsk_nov21.jpg";s:8:"filesize";i:67523;s:5:"sizes";a:5:{s:6:"medium";a:5:{s:4:"file";s:51:"OS0002_1140x400Px_for_Chelyabinsk_nov21-300x105.jpg";s:5:"width";i:300;s:6:"height";i:105;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:8355;}s:5:"large";a:5:{s:4:"file";s:52:"OS0002_1140x400Px_for_Chelyabinsk_nov21-1024x359.jpg";s:5:"width";i:1024;s:6:"height";i:359;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:55352;}s:9:"thumbnail";a:5:{s:4:"file";s:51:"OS0002_1140x400Px_for_Chelyabinsk_nov21-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:8223;}s:12:"medium_large";a:5:{s:4:"file";s:51:"OS0002_1140x400Px_for_Chelyabinsk_nov21-768x269.jpg";s:5:"width";i:768;s:6:"height";i:269;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:34586;}s:14:"post-thumbnail";a:5:{s:4:"file";s:51:"OS0002_1140x400Px_for_Chelyabinsk_nov21-600x350.jpg";s:5:"width";i:600;s:6:"height";i:350;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:38921;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(46, 25, '_wp_attached_file', '2022/07/d3Ycun8SIRM1VGiTHNMlGK8JSxPf5fnUzBsh3lR6.jpg'),
(47, 25, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:666;s:6:"height";i:666;s:4:"file";s:52:"2022/07/d3Ycun8SIRM1VGiTHNMlGK8JSxPf5fnUzBsh3lR6.jpg";s:8:"filesize";i:559081;s:5:"sizes";a:3:{s:6:"medium";a:5:{s:4:"file";s:52:"d3Ycun8SIRM1VGiTHNMlGK8JSxPf5fnUzBsh3lR6-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:31443;}s:9:"thumbnail";a:5:{s:4:"file";s:52:"d3Ycun8SIRM1VGiTHNMlGK8JSxPf5fnUzBsh3lR6-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:8948;}s:14:"post-thumbnail";a:5:{s:4:"file";s:52:"d3Ycun8SIRM1VGiTHNMlGK8JSxPf5fnUzBsh3lR6-600x350.jpg";s:5:"width";i:600;s:6:"height";i:350;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:60802;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"1";s:8:"keywords";a:0:{}}}'),
(48, 26, '_wp_attached_file', '2022/07/scrollable_banner_image_two.jpg'),
(49, 26, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:915;s:6:"height";i:985;s:4:"file";s:39:"2022/07/scrollable_banner_image_two.jpg";s:8:"filesize";i:106651;s:5:"sizes";a:4:{s:6:"medium";a:5:{s:4:"file";s:39:"scrollable_banner_image_two-279x300.jpg";s:5:"width";i:279;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:18612;}s:9:"thumbnail";a:5:{s:4:"file";s:39:"scrollable_banner_image_two-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:6674;}s:12:"medium_large";a:5:{s:4:"file";s:39:"scrollable_banner_image_two-768x827.jpg";s:5:"width";i:768;s:6:"height";i:827;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:98685;}s:14:"post-thumbnail";a:5:{s:4:"file";s:39:"scrollable_banner_image_two-600x350.jpg";s:5:"width";i:600;s:6:"height";i:350;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:39377;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(50, 27, '_wp_attached_file', '2022/07/ц1.png'),
(51, 27, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:1500;s:6:"height";i:1000;s:4:"file";s:15:"2022/07/ц1.png";s:8:"filesize";i:1811014;s:5:"sizes";a:5:{s:6:"medium";a:5:{s:4:"file";s:15:"ц1-300x200.png";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:99091;}s:5:"large";a:5:{s:4:"file";s:16:"ц1-1024x683.png";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:829589;}s:9:"thumbnail";a:5:{s:4:"file";s:15:"ц1-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:42176;}s:12:"medium_large";a:5:{s:4:"file";s:15:"ц1-768x512.png";s:5:"width";i:768;s:6:"height";i:512;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:495730;}s:14:"post-thumbnail";a:5:{s:4:"file";s:15:"ц1-600x350.png";s:5:"width";i:600;s:6:"height";i:350;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:285259;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(52, 28, '_wp_attached_file', '2022/07/ц3.jpg'),
(53, 28, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:450;s:6:"height";i:299;s:4:"file";s:15:"2022/07/ц3.jpg";s:8:"filesize";i:19005;s:5:"sizes";a:2:{s:6:"medium";a:5:{s:4:"file";s:15:"ц3-300x199.jpg";s:5:"width";i:300;s:6:"height";i:199;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:12022;}s:9:"thumbnail";a:5:{s:4:"file";s:15:"ц3-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:6433;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(54, 29, '_wp_attached_file', '2022/07/ц4.png'),
(55, 29, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:640;s:6:"height";i:350;s:4:"file";s:15:"2022/07/ц4.png";s:8:"filesize";i:243995;s:5:"sizes";a:3:{s:6:"medium";a:5:{s:4:"file";s:15:"ц4-300x164.png";s:5:"width";i:300;s:6:"height";i:164;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:66547;}s:9:"thumbnail";a:5:{s:4:"file";s:15:"ц4-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:35734;}s:14:"post-thumbnail";a:5:{s:4:"file";s:15:"ц4-600x350.png";s:5:"width";i:600;s:6:"height";i:350;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:236239;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(56, 30, '_wp_attached_file', '2022/07/ц5.jpg'),
(57, 30, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:500;s:6:"height";i:323;s:4:"file";s:15:"2022/07/ц5.jpg";s:8:"filesize";i:30081;s:5:"sizes";a:2:{s:6:"medium";a:5:{s:4:"file";s:15:"ц5-300x194.jpg";s:5:"width";i:300;s:6:"height";i:194;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:8602;}s:9:"thumbnail";a:5:{s:4:"file";s:15:"ц5-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:5016;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(58, 31, '_wp_attached_file', '2022/07/ц6.jpg'),
(59, 31, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:284;s:6:"height";i:177;s:4:"file";s:15:"2022/07/ц6.jpg";s:8:"filesize";i:6295;s:5:"sizes";a:1:{s:9:"thumbnail";a:5:{s:4:"file";s:15:"ц6-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:4733;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(60, 14, '_wp_trash_meta_status', 'publish'),
(61, 14, '_wp_trash_meta_time', '1657095583'),
(62, 32, '_wp_trash_meta_status', 'publish'),
(63, 32, '_wp_trash_meta_time', '1657095983'),
(64, 33, '_wp_trash_meta_status', 'publish'),
(65, 33, '_wp_trash_meta_time', '1657096008') ;

#
# End of data contents of table `wp_postmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_posts`
#

DROP TABLE IF EXISTS `wp_posts`;


#
# Table structure of table `wp_posts`
#

CREATE TABLE `wp_posts` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_author` bigint(20) unsigned NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_title` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_excerpt` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'open',
  `post_password` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `post_name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `to_ping` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `pinged` text COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `post_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `guid` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT '0',
  `post_type` varchar(20) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `post_name` (`post_name`(191)),
  KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  KEY `post_parent` (`post_parent`),
  KEY `post_author` (`post_author`)
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_posts`
#
INSERT INTO `wp_posts` ( `ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(1, 1, '2022-07-06 08:52:02', '2022-07-06 05:52:02', '<!-- wp:paragraph -->\n<p>Добро пожаловать в WordPress. Это ваша первая запись. Отредактируйте или удалите ее, затем начинайте создавать!</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:image {"id":7,"sizeSlug":"full","linkDestination":"none"} -->\n<figure class="wp-block-image size-full"><img src="http://localhost/wp.local/wp-content/uploads/2022/07/avatar.jpg" alt="" class="wp-image-7"/></figure>\n<!-- /wp:image -->', 'Mир!', '', 'publish', 'open', 'open', '', '%d0%bf%d1%80%d0%b8%d0%b2%d0%b5%d1%82-%d0%bc%d0%b8%d1%80', '', '', '2022-07-06 09:23:42', '2022-07-06 06:23:42', '', 0, 'http://localhost/wp.local/?p=1', 0, 'post', '', 2),
(2, 1, '2022-07-06 08:52:02', '2022-07-06 05:52:02', '<!-- wp:paragraph -->\n<p>Это пример страницы. От записей в блоге она отличается тем, что остаётся на одном месте и отображается в меню сайта (в большинстве тем). На странице &laquo;Детали&raquo; владельцы сайтов обычно рассказывают о себе потенциальным посетителям. Например, так:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class="wp-block-quote"><p>Привет! Днём я курьер, а вечером &#8212; подающий надежды актёр. Это мой блог. Я живу в Ростове-на-Дону, люблю своего пса Джека и пинаколаду. (И ещё попадать под дождь.)</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>...или так:</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class="wp-block-quote"><p>Компания &laquo;Штучки XYZ&raquo; была основана в 1971 году и с тех пор производит качественные штучки. Компания находится в Готэм-сити, имеет штат из более чем 2000 сотрудников и приносит много пользы жителям Готэма.</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>Перейдите <a href="http://localhost/wp.local/wp-admin/">в консоль</a>, чтобы удалить эту страницу и создать новые. Успехов!</p>\n<!-- /wp:paragraph -->', 'Пример страницы', '', 'publish', 'closed', 'open', '', 'sample-page', '', '', '2022-07-06 08:52:02', '2022-07-06 05:52:02', '', 0, 'http://localhost/wp.local/?page_id=2', 0, 'page', '', 0),
(3, 1, '2022-07-06 08:52:02', '2022-07-06 05:52:02', '<!-- wp:heading --><h2>Кто мы</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class="privacy-policy-tutorial">Предлагаемый текст: </strong>Наш адрес сайта: http://localhost/wp.local.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Комментарии</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class="privacy-policy-tutorial">Предлагаемый текст: </strong>Если посетитель оставляет комментарий на сайте, мы собираем данные указанные в форме комментария, а также IP адрес посетителя и данные user-agent браузера с целью определения спама.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>Анонимизированная строка создаваемая из вашего адреса email ("хеш") может предоставляться сервису Gravatar, чтобы определить используете ли вы его. Политика конфиденциальности Gravatar доступна здесь: https://automattic.com/privacy/ . После одобрения комментария ваше изображение профиля будет видимым публично в контексте вашего комментария.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Медиафайлы</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class="privacy-policy-tutorial">Предлагаемый текст: </strong>Если вы зарегистрированный пользователь и загружаете фотографии на сайт, вам возможно следует избегать загрузки изображений с метаданными EXIF, так как они могут содержать данные вашего месторасположения по GPS. Посетители могут извлечь эту информацию скачав изображения с сайта.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Куки</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class="privacy-policy-tutorial">Предлагаемый текст: </strong>Если вы оставляете комментарий на нашем сайте, вы можете включить сохранение вашего имени, адреса email и вебсайта в куки. Это делается для вашего удобства, чтобы не заполнять данные снова при повторном комментировании. Эти куки хранятся в течение одного года.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>Если у вас есть учетная запись на сайте и вы войдете в неё, мы установим временный куки для определения поддержки куки вашим браузером, куки не содержит никакой личной информации и удаляется при закрытии вашего браузера.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>При входе в учетную запись мы также устанавливаем несколько куки с данными входа и настройками экрана. Куки входа хранятся в течение двух дней, куки с настройками экрана - год. Если вы выберете возможность "Запомнить меня", данные о входе будут сохраняться в течение двух недель. При выходе из учетной записи куки входа будут удалены.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>При редактировании или публикации статьи в браузере будет сохранен дополнительный куки, он не содержит персональных данных и содержит только ID записи отредактированной вами, истекает через 1 день.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Встраиваемое содержимое других вебсайтов</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class="privacy-policy-tutorial">Предлагаемый текст: </strong>Статьи на этом сайте могут включать встраиваемое содержимое (например видео, изображения, статьи и др.), подобное содержимое ведет себя так же, как если бы посетитель зашел на другой сайт.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>Эти сайты могут собирать данные о вас, использовать куки, внедрять дополнительное отслеживание третьей стороной и следить за вашим взаимодействием с внедренным содержимым, включая отслеживание взаимодействия, если у вас есть учетная запись и вы авторизовались на том сайте.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>С кем мы делимся вашими данными</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class="privacy-policy-tutorial">Предлагаемый текст: </strong>Если вы запросите сброс пароля, ваш IP будет указан в email-сообщении о сбросе.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Как долго мы храним ваши данные</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class="privacy-policy-tutorial">Предлагаемый текст: </strong>Если вы оставляете комментарий, то сам комментарий и его метаданные сохраняются неопределенно долго. Это делается для того, чтобы определять и одобрять последующие комментарии автоматически, вместо помещения их в очередь на одобрение.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>Для пользователей с регистрацией на нашем сайте мы храним ту личную информацию, которую они указывают в своем профиле. Все пользователи могут видеть, редактировать или удалить свою информацию из профиля в любое время (кроме имени пользователя). Администрация вебсайта также может видеть и изменять эту информацию.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Какие у вас права на ваши данные</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class="privacy-policy-tutorial">Предлагаемый текст: </strong>При наличии учетной записи на сайте или если вы оставляли комментарии, то вы можете запросить файл экспорта персональных данных, которые мы сохранили о вас, включая предоставленные вами данные. Вы также можете запросить удаление этих данных, это не включает данные, которые мы обязаны хранить в административных целях, по закону или целях безопасности.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Куда отправляются ваши данные</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class="privacy-policy-tutorial">Предлагаемый текст: </strong>Комментарии пользователей могут проверяться автоматическим сервисом определения спама.</p><!-- /wp:paragraph -->', 'Политика конфиденциальности', '', 'draft', 'closed', 'open', '', 'privacy-policy', '', '', '2022-07-06 08:52:02', '2022-07-06 05:52:02', '', 0, 'http://localhost/wp.local/?page_id=3', 0, 'page', '', 0),
(4, 1, '2022-07-06 08:52:49', '0000-00-00 00:00:00', '', 'Черновик', '', 'auto-draft', 'open', 'open', '', '', '', '', '2022-07-06 08:52:49', '0000-00-00 00:00:00', '', 0, 'http://localhost/wp.local/?p=4', 0, 'post', '', 0),
(5, 1, '2022-07-06 09:19:47', '2022-07-06 06:19:47', '{"version":2,"isGlobalStylesUserThemeJSON":true}', 'Custom Styles', '', 'publish', 'closed', 'closed', '', 'wp-global-styles-twentytwentytwo', '', '', '2022-07-06 09:19:47', '2022-07-06 06:19:47', '', 0, 'http://localhost/wp.local/?p=5', 0, 'wp_global_styles', '', 0),
(6, 1, '2022-07-06 09:22:46', '2022-07-06 06:22:46', '<!-- wp:paragraph -->\n<p>Добро пожаловать в WordPress. Это ваша первая запись. Отредактируйте или удалите ее, затем начинайте создавать!</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:image {"id":7,"sizeSlug":"full","linkDestination":"none"} -->\n<figure class="wp-block-image size-full"><img src="http://localhost/wp.local/wp-content/uploads/2022/07/avatar.jpg" alt="" class="wp-image-7"/></figure>\n<!-- /wp:image -->\n\n<!-- wp:gallery {"linkTo":"none"} -->\n<figure class="wp-block-gallery has-nested-images columns-default is-cropped"><!-- wp:image -->\n<figure class="wp-block-image"><img alt=""/></figure>\n<!-- /wp:image --></figure>\n<!-- /wp:gallery -->', 'Mир!', '', 'inherit', 'closed', 'closed', '', '1-autosave-v1', '', '', '2022-07-06 09:22:46', '2022-07-06 06:22:46', '', 1, 'http://localhost/wp.local/?p=6', 0, 'revision', '', 0),
(7, 1, '2022-07-06 09:21:16', '2022-07-06 06:21:16', '', 'avatar', '', 'inherit', 'open', 'closed', '', 'avatar', '', '', '2022-07-06 09:21:16', '2022-07-06 06:21:16', '', 1, 'http://localhost/wp.local/wp-content/uploads/2022/07/avatar.jpg', 0, 'attachment', 'image/jpeg', 0),
(8, 1, '2022-07-06 09:22:46', '2022-07-06 06:22:46', '', 'avatar-1', '', 'inherit', 'open', 'closed', '', 'avatar-1', '', '', '2022-07-06 09:22:46', '2022-07-06 06:22:46', '', 1, 'http://localhost/wp.local/wp-content/uploads/2022/07/avatar-1.jpg', 0, 'attachment', 'image/jpeg', 0),
(9, 1, '2022-07-06 09:23:42', '2022-07-06 06:23:42', '<!-- wp:paragraph -->\n<p>Добро пожаловать в WordPress. Это ваша первая запись. Отредактируйте или удалите ее, затем начинайте создавать!</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:image {"id":7,"sizeSlug":"full","linkDestination":"none"} -->\n<figure class="wp-block-image size-full"><img src="http://localhost/wp.local/wp-content/uploads/2022/07/avatar.jpg" alt="" class="wp-image-7"/></figure>\n<!-- /wp:image -->', 'Mир!', '', 'inherit', 'closed', 'closed', '', '1-revision-v1', '', '', '2022-07-06 09:23:42', '2022-07-06 06:23:42', '', 1, 'http://localhost/wp.local/?p=9', 0, 'revision', '', 0),
(10, 1, '2022-07-06 09:27:36', '2022-07-06 06:27:36', '<!-- wp:paragraph {"textColor":"pale-cyan-blue","fontSize":"large"} -->\n<p class="has-pale-cyan-blue-color has-text-color has-large-font-size">hello</p>\n<!-- /wp:paragraph -->', 'MIR', '', 'publish', 'open', 'open', '', 'mir', '', '', '2022-07-06 09:32:06', '2022-07-06 06:32:06', '', 0, 'http://localhost/wp.local/?p=10', 0, 'post', '', 0),
(11, 1, '2022-07-06 09:27:36', '2022-07-06 06:27:36', '<!-- wp:paragraph -->\n<p>hello</p>\n<!-- /wp:paragraph -->', 'MIR', '', 'inherit', 'closed', 'closed', '', '10-revision-v1', '', '', '2022-07-06 09:27:36', '2022-07-06 06:27:36', '', 10, 'http://localhost/wp.local/?p=11', 0, 'revision', '', 0),
(12, 1, '2022-07-06 09:32:06', '2022-07-06 06:32:06', '<!-- wp:paragraph {"textColor":"pale-cyan-blue","fontSize":"large"} -->\n<p class="has-pale-cyan-blue-color has-text-color has-large-font-size">hello</p>\n<!-- /wp:paragraph -->', 'MIR', '', 'inherit', 'closed', 'closed', '', '10-revision-v1', '', '', '2022-07-06 09:32:06', '2022-07-06 06:32:06', '', 10, 'http://localhost/wp.local/?p=12', 0, 'revision', '', 0),
(13, 1, '2022-07-06 10:48:13', '2022-07-06 07:48:13', '{"ecommerce-goldly::goldly_contact_info_number":{"value":"+7-904-306-92-32","type":"theme_mod","user_id":1,"date_modified_gmt":"2022-07-06 07:41:09"},"ecommerce-goldly::goldly_email_info_number":{"value":"20300513@live.inueco.ru","type":"theme_mod","user_id":1,"date_modified_gmt":"2022-07-06 07:41:09"},"ecommerce-goldly::goldly_header_layout":{"value":"header4","type":"theme_mod","user_id":1,"date_modified_gmt":"2022-07-06 07:42:10"},"ecommerce-goldly::goldly_mobile_navmenu_bg_color":{"value":"#273641","type":"theme_mod","user_id":1,"date_modified_gmt":"2022-07-06 07:43:09"},"ecommerce-goldly::goldly_breadcrumb_bg_color":{"value":"#c8c9cb","type":"theme_mod","user_id":1,"date_modified_gmt":"2022-07-06 07:44:10"},"blogname":{"value":"name","type":"option","user_id":1,"date_modified_gmt":"2022-07-06 07:44:10"},"blogdescription":{"value":"text1","type":"option","user_id":1,"date_modified_gmt":"2022-07-06 07:44:10"},"ecommerce-goldly::goldly_twitter_link":{"value":"https:\\/\\/twitter.com\\/","type":"theme_mod","user_id":1,"date_modified_gmt":"2022-07-06 07:45:10"},"ecommerce-goldly::goldly_facebook_link":{"value":"https:\\/\\/www.facebook.com\\/","type":"theme_mod","user_id":1,"date_modified_gmt":"2022-07-06 07:45:10"},"ecommerce-goldly::goldly_social_icon_hover_color":{"value":"#214462","type":"theme_mod","user_id":1,"date_modified_gmt":"2022-07-06 07:46:17"},"ecommerce-goldly::goldly_social_icon_bg_color":{"value":"#273641","type":"theme_mod","user_id":1,"date_modified_gmt":"2022-07-06 07:46:17"},"ecommerce-goldly::goldly_transparent_header_text_color":{"value":"#ffffff","type":"theme_mod","user_id":1,"date_modified_gmt":"2022-07-06 07:46:17"}}', '', '', 'trash', 'closed', 'closed', '', '92e701eb-aa1a-4a4b-a638-9490e04b29b1', '', '', '2022-07-06 10:48:13', '2022-07-06 07:48:13', '', 0, 'http://localhost/wp.local/?p=13', 0, 'customize_changeset', '', 0),
(14, 1, '2022-07-06 11:19:43', '2022-07-06 08:19:43', '{"ecommerce-goldly::goldly_call_menu_btn_title":{"value":"\\u0420\\u0435\\u0433\\u0438\\u0441\\u0442\\u0440\\u0430\\u0446\\u0438\\u044f","type":"theme_mod","user_id":1,"date_modified_gmt":"2022-07-06 07:56:00"},"ecommerce-goldly::goldly_body_fontfamily":{"value":"1","type":"theme_mod","user_id":1,"date_modified_gmt":"2022-07-06 07:56:00"},"blogname":{"value":"BushWick","type":"option","user_id":1,"date_modified_gmt":"2022-07-06 07:56:57"},"ecommerce-goldly::goldly_Heading1_fontfamily":{"value":"1","type":"theme_mod","user_id":1,"date_modified_gmt":"2022-07-06 07:56:57"},"ecommerce-goldly::goldly_Heading2_fontfamily":{"value":"1","type":"theme_mod","user_id":1,"date_modified_gmt":"2022-07-06 07:56:57"},"ecommerce-goldly::goldly_Heading3_fontfamily":{"value":"1","type":"theme_mod","user_id":1,"date_modified_gmt":"2022-07-06 07:56:57"},"blogdescription":{"value":"Magazin prodazhi chasov ","type":"option","user_id":1,"date_modified_gmt":"2022-07-06 07:58:00"},"ecommerce-goldly::featuredimage_slider_tab":{"value":"general","type":"theme_mod","user_id":1,"date_modified_gmt":"2022-07-06 07:58:00"},"ecommerce-goldly::about_title_section":{"value":"\\u041e \\u043d\\u0430\\u0441","type":"theme_mod","user_id":1,"date_modified_gmt":"2022-07-06 07:59:00"},"ecommerce-goldly::featured_section_tab":{"value":"general","type":"theme_mod","user_id":1,"date_modified_gmt":"2022-07-06 07:59:46"},"ecommerce-goldly::header_image":{"value":"remove-header","type":"theme_mod","user_id":1,"date_modified_gmt":"2022-07-06 08:02:18"},"ecommerce-goldly::header_image_data":{"value":"remove-header","type":"theme_mod","user_id":1,"date_modified_gmt":"2022-07-06 08:02:18"},"sidebars_widgets[footer1]":{"value":["block-9"],"type":"option","user_id":1,"date_modified_gmt":"2022-07-06 08:02:18"},"widget_block[9]":{"value":{"raw_instance":{"content":"<!-- wp:gallery {\\"linkTo\\":\\"none\\"} -->\\n<figure class=\\"wp-block-gallery has-nested-images columns-default is-cropped\\"><\\/figure>\\n<!-- \\/wp:gallery -->"}},"type":"option","user_id":1,"date_modified_gmt":"2022-07-06 08:02:18"},"sidebars_widgets[footer3]":{"value":[],"type":"option","user_id":1,"date_modified_gmt":"2022-07-06 08:03:16"},"sidebars_widgets[footer5]":{"value":[],"type":"option","user_id":1,"date_modified_gmt":"2022-07-06 08:03:16"},"sidebars_widgets[section]":{"value":[],"type":"option","user_id":1,"date_modified_gmt":"2022-07-06 08:04:17"},"ecommerce-goldly::background_image":{"value":"","type":"theme_mod","user_id":1,"date_modified_gmt":"2022-07-06 08:05:24"},"site_icon":{"value":"","type":"option","user_id":1,"date_modified_gmt":"2022-07-06 08:06:17"},"ecommerce-goldly::custom_logo":{"value":"","type":"theme_mod","user_id":1,"date_modified_gmt":"2022-07-06 08:06:17"},"ecommerce-goldly::goldly_breadcrumb_bg_image":{"value":"","type":"theme_mod","user_id":1,"date_modified_gmt":"2022-07-06 08:19:43"},"ecommerce-goldly::featured_image_sliders_1":{"value":"http:\\/\\/localhost\\/wp.local\\/wp-content\\/uploads\\/2022\\/07\\/Baner-v-Galereyu-KOSMOS_MOB-6.jpg","type":"theme_mod","user_id":1,"date_modified_gmt":"2022-07-06 08:06:45"},"ecommerce-goldly::featured_image_sliders_2":{"value":"http:\\/\\/localhost\\/wp.local\\/wp-content\\/uploads\\/2022\\/07\\/d3Ycun8SIRM1VGiTHNMlGK8JSxPf5fnUzBsh3lR6.jpg","type":"theme_mod","user_id":1,"date_modified_gmt":"2022-07-06 08:08:05"},"ecommerce-goldly::about_image_sliders":{"value":"http:\\/\\/localhost\\/wp.local\\/wp-content\\/uploads\\/2022\\/07\\/Baner-v-Galereyu-KOSMOS_MOB-5.jpg","type":"theme_mod","user_id":1,"date_modified_gmt":"2022-07-06 08:09:04"},"ecommerce-goldly::our_portfolio_image_1":{"value":"http:\\/\\/localhost\\/wp.local\\/wp-content\\/uploads\\/2022\\/07\\/d3Ycun8SIRM1VGiTHNMlGK8JSxPf5fnUzBsh3lR6.jpg","type":"theme_mod","user_id":1,"date_modified_gmt":"2022-07-06 08:09:04"},"ecommerce-goldly::our_portfolio_image_2":{"value":"http:\\/\\/localhost\\/wp.local\\/wp-content\\/uploads\\/2022\\/07\\/d3Ycun8SIRM1VGiTHNMlGK8JSxPf5fnUzBsh3lR6.jpg","type":"theme_mod","user_id":1,"date_modified_gmt":"2022-07-06 08:09:04"},"ecommerce-goldly::our_portfolio_image_3":{"value":"http:\\/\\/localhost\\/wp.local\\/wp-content\\/uploads\\/2022\\/07\\/d3Ycun8SIRM1VGiTHNMlGK8JSxPf5fnUzBsh3lR6.jpg","type":"theme_mod","user_id":1,"date_modified_gmt":"2022-07-06 08:09:04"},"ecommerce-goldly::our_team_image1":{"value":"http:\\/\\/localhost\\/wp.local\\/wp-content\\/uploads\\/2022\\/07\\/OS0002_1140x400Px_for_Chelyabinsk_nov21.jpg","type":"theme_mod","user_id":1,"date_modified_gmt":"2022-07-06 08:10:05"},"ecommerce-goldly::our_team_image2":{"value":"http:\\/\\/localhost\\/wp.local\\/wp-content\\/uploads\\/2022\\/07\\/OS0002_1140x400Px_for_Chelyabinsk_nov21.jpg","type":"theme_mod","user_id":1,"date_modified_gmt":"2022-07-06 08:10:05"},"ecommerce-goldly::our_team_image3":{"value":"http:\\/\\/localhost\\/wp.local\\/wp-content\\/uploads\\/2022\\/07\\/OS0002_1140x400Px_for_Chelyabinsk_nov21.jpg","type":"theme_mod","user_id":1,"date_modified_gmt":"2022-07-06 08:10:05"},"ecommerce-goldly::our_team_image4":{"value":"http:\\/\\/localhost\\/wp.local\\/wp-content\\/uploads\\/2022\\/07\\/OS0002_1140x400Px_for_Chelyabinsk_nov21.jpg","type":"theme_mod","user_id":1,"date_modified_gmt":"2022-07-06 08:10:05"},"ecommerce-goldly::our_testimonial_image_1":{"value":"http:\\/\\/localhost\\/wp.local\\/wp-content\\/uploads\\/2022\\/07\\/cropped-Baner-v-Galereyu-KOSMOS_MOB-4.jpg","type":"theme_mod","user_id":1,"date_modified_gmt":"2022-07-06 08:10:05"},"ecommerce-goldly::our_testimonial_image_3":{"value":"http:\\/\\/localhost\\/wp.local\\/wp-content\\/uploads\\/2022\\/07\\/OS0002_1140x400Px_for_Chelyabinsk_nov21.jpg","type":"theme_mod","user_id":1,"date_modified_gmt":"2022-07-06 08:10:05"},"ecommerce-goldly::our_testimonial_image_2":{"value":"http:\\/\\/localhost\\/wp.local\\/wp-content\\/uploads\\/2022\\/07\\/scrollable_banner_image_two.jpg","type":"theme_mod","user_id":1,"date_modified_gmt":"2022-07-06 08:11:13"},"ecommerce-goldly::our_services_title_4":{"value":"\\u0432\\u043f\\u0440\\u0430\\u0432\\u043f\\u0440\\u0430\\u0432\\u0440\\u043f","type":"theme_mod","user_id":1,"date_modified_gmt":"2022-07-06 08:13:40"},"ecommerce-goldly::our_services_title_link_4":{"value":"#","type":"theme_mod","user_id":1,"date_modified_gmt":"2022-07-06 08:13:40"},"ecommerce-goldly::our_services_description_4":{"value":"\\u043a\\u0435\\u043f\\u0430\\u0432\\u043f\\u0430\\u0432\\u043f\\u0440","type":"theme_mod","user_id":1,"date_modified_gmt":"2022-07-06 08:13:40"},"ecommerce-goldly::our_sponsors_image_1":{"value":"http:\\/\\/localhost\\/wp.local\\/wp-content\\/uploads\\/2022\\/07\\/\\u04461.png","type":"theme_mod","user_id":1,"date_modified_gmt":"2022-07-06 08:13:40"},"ecommerce-goldly::our_sponsors_image_2":{"value":"http:\\/\\/localhost\\/wp.local\\/wp-content\\/uploads\\/2022\\/07\\/\\u04463.jpg","type":"theme_mod","user_id":1,"date_modified_gmt":"2022-07-06 08:14:41"},"ecommerce-goldly::our_sponsors_image_3":{"value":"http:\\/\\/localhost\\/wp.local\\/wp-content\\/uploads\\/2022\\/07\\/\\u04464.png","type":"theme_mod","user_id":1,"date_modified_gmt":"2022-07-06 08:14:41"},"ecommerce-goldly::our_sponsors_image_4":{"value":"http:\\/\\/localhost\\/wp.local\\/wp-content\\/uploads\\/2022\\/07\\/\\u04465.jpg","type":"theme_mod","user_id":1,"date_modified_gmt":"2022-07-06 08:14:41"},"ecommerce-goldly::our_sponsors_image_5":{"value":"http:\\/\\/localhost\\/wp.local\\/wp-content\\/uploads\\/2022\\/07\\/\\u04466.jpg","type":"theme_mod","user_id":1,"date_modified_gmt":"2022-07-06 08:14:41"},"ecommerce-goldly::goldly_diseble":{"value":"Goldly_our_services_section","type":"theme_mod","user_id":1,"date_modified_gmt":"2022-07-06 08:14:41"},"ecommerce-goldly::features_one_icon1":{"value":"fa fa-user","type":"theme_mod","user_id":1,"date_modified_gmt":"2022-07-06 08:18:41"},"widget_block[3]":{"value":{"raw_instance":{"content":"<!-- wp:group -->\\n<div class=\\"wp-block-group\\"><!-- wp:heading -->\\n<h2>\\u0421\\u0432\\u0435\\u0436\\u0438\\u0435 \\u0437\\u0430\\u043f\\u0438\\u0441\\u0438<br><br><\\/h2>\\n<!-- \\/wp:heading --><\\/div>\\n<!-- \\/wp:group -->"}},"type":"option","user_id":1,"date_modified_gmt":"2022-07-06 08:19:42"},"widget_block[4]":{"value":{"raw_instance":{"content":"<!-- wp:group -->\\n<div class=\\"wp-block-group\\"><!-- wp:heading -->\\n<h2>\\u0421\\u0432\\u0435\\u0436\\u0438\\u0435 \\u043a\\u043e\\u043c\\u043c\\u0435\\u043d\\u0442\\u0430\\u0440\\u0438\\u0438<br><br><\\/h2>\\n<!-- \\/wp:heading --><\\/div>\\n<!-- \\/wp:group -->"}},"type":"option","user_id":1,"date_modified_gmt":"2022-07-06 08:19:42"},"widget_block[5]":{"value":{"raw_instance":{"content":"<!-- wp:group -->\\n<div class=\\"wp-block-group\\"><!-- wp:heading -->\\n<h2>\\u0410\\u0440\\u0445\\u0438\\u0432\\u044b<br><br><\\/h2>\\n<!-- \\/wp:heading --><\\/div>\\n<!-- \\/wp:group -->"}},"type":"option","user_id":1,"date_modified_gmt":"2022-07-06 08:19:42"},"widget_block[6]":{"value":{"raw_instance":{"content":"<!-- wp:group -->\\n<div class=\\"wp-block-group\\"><!-- wp:heading -->\\n<h2>\\u0420\\u0443\\u0431\\u0440\\u0438\\u043a\\u0438<br><br><\\/h2>\\n<!-- \\/wp:heading --><\\/div>\\n<!-- \\/wp:group -->"}},"type":"option","user_id":1,"date_modified_gmt":"2022-07-06 08:19:42"},"ecommerce-goldly::goldly_Heading_fontfamily":{"value":"1","type":"theme_mod","user_id":1,"date_modified_gmt":"2022-07-06 08:19:43"}}', '', '', 'trash', 'closed', 'closed', '', '47d8f061-2b0f-4dae-83e1-6932d2ec53ab', '', '', '2022-07-06 11:19:43', '2022-07-06 08:19:43', '', 0, 'http://localhost/wp.local/?p=14', 0, 'customize_changeset', '', 0),
(15, 1, '2022-07-06 11:00:32', '2022-07-06 08:00:32', '', 'Baner-v-Galereyu-KOSMOS_MOB', '', 'inherit', 'open', 'closed', '', 'baner-v-galereyu-kosmos_mob', '', '', '2022-07-06 11:00:32', '2022-07-06 08:00:32', '', 0, 'http://localhost/wp.local/wp-content/uploads/2022/07/Baner-v-Galereyu-KOSMOS_MOB.jpg', 0, 'attachment', 'image/jpeg', 0),
(16, 1, '2022-07-06 11:00:54', '2022-07-06 08:00:54', '', 'cropped-Baner-v-Galereyu-KOSMOS_MOB.jpg', '', 'inherit', 'open', 'closed', '', 'cropped-baner-v-galereyu-kosmos_mob-jpg', '', '', '2022-07-06 11:00:54', '2022-07-06 08:00:54', '', 0, 'http://localhost/wp.local/wp-content/uploads/2022/07/cropped-Baner-v-Galereyu-KOSMOS_MOB.jpg', 0, 'attachment', 'image/jpeg', 0),
(17, 1, '2022-07-06 11:02:17', '2022-07-06 08:02:17', '', 'Baner-v-Galereyu-KOSMOS_MOB-1', '', 'inherit', 'open', 'closed', '', 'baner-v-galereyu-kosmos_mob-1', '', '', '2022-07-06 11:02:17', '2022-07-06 08:02:17', '', 0, 'http://localhost/wp.local/wp-content/uploads/2022/07/Baner-v-Galereyu-KOSMOS_MOB-1.jpg', 0, 'attachment', 'image/jpeg', 0),
(18, 1, '2022-07-06 11:02:31', '2022-07-06 08:02:31', '', 'Baner-v-Galereyu-KOSMOS_MOB-2', '', 'inherit', 'open', 'closed', '', 'baner-v-galereyu-kosmos_mob-2', '', '', '2022-07-06 11:02:31', '2022-07-06 08:02:31', '', 0, 'http://localhost/wp.local/wp-content/uploads/2022/07/Baner-v-Galereyu-KOSMOS_MOB-2.jpg', 0, 'attachment', 'image/jpeg', 0),
(19, 1, '2022-07-06 11:02:50', '2022-07-06 08:02:50', '', 'Baner-v-Galereyu-KOSMOS_MOB-3', '', 'inherit', 'open', 'closed', '', 'baner-v-galereyu-kosmos_mob-3', '', '', '2022-07-06 11:02:50', '2022-07-06 08:02:50', '', 0, 'http://localhost/wp.local/wp-content/uploads/2022/07/Baner-v-Galereyu-KOSMOS_MOB-3.jpg', 0, 'attachment', 'image/jpeg', 0),
(20, 1, '2022-07-06 11:03:06', '2022-07-06 08:03:06', '', 'Baner-v-Galereyu-KOSMOS_MOB-4', '', 'inherit', 'open', 'closed', '', 'baner-v-galereyu-kosmos_mob-4', '', '', '2022-07-06 11:03:06', '2022-07-06 08:03:06', '', 0, 'http://localhost/wp.local/wp-content/uploads/2022/07/Baner-v-Galereyu-KOSMOS_MOB-4.jpg', 0, 'attachment', 'image/jpeg', 0),
(21, 1, '2022-07-06 11:03:26', '2022-07-06 08:03:26', '', 'Baner-v-Galereyu-KOSMOS_MOB-5', '', 'inherit', 'open', 'closed', '', 'baner-v-galereyu-kosmos_mob-5', '', '', '2022-07-06 11:03:26', '2022-07-06 08:03:26', '', 0, 'http://localhost/wp.local/wp-content/uploads/2022/07/Baner-v-Galereyu-KOSMOS_MOB-5.jpg', 0, 'attachment', 'image/jpeg', 0),
(22, 1, '2022-07-06 11:04:19', '2022-07-06 08:04:19', '', 'Baner-v-Galereyu-KOSMOS_MOB', '', 'inherit', 'open', 'closed', '', 'baner-v-galereyu-kosmos_mob-6', '', '', '2022-07-06 11:04:19', '2022-07-06 08:04:19', '', 0, 'http://localhost/wp.local/wp-content/uploads/2022/07/Baner-v-Galereyu-KOSMOS_MOB-6.jpg', 0, 'attachment', 'image/jpeg', 0),
(23, 1, '2022-07-06 11:05:42', '2022-07-06 08:05:42', 'http://localhost/wp.local/wp-content/uploads/2022/07/cropped-Baner-v-Galereyu-KOSMOS_MOB-4.jpg', 'cropped-Baner-v-Galereyu-KOSMOS_MOB-4.jpg', '', 'inherit', 'open', 'closed', '', 'cropped-baner-v-galereyu-kosmos_mob-4-jpg', '', '', '2022-07-06 11:05:42', '2022-07-06 08:05:42', '', 0, 'http://localhost/wp.local/wp-content/uploads/2022/07/cropped-Baner-v-Galereyu-KOSMOS_MOB-4.jpg', 0, 'attachment', 'image/jpeg', 0),
(24, 1, '2022-07-06 11:07:19', '2022-07-06 08:07:19', '', 'OS0002_1140x400Px_for_Chelyabinsk_nov\'21', '', 'inherit', 'open', 'closed', '', 'os0002_1140x400px_for_chelyabinsk_nov21', '', '', '2022-07-06 11:07:19', '2022-07-06 08:07:19', '', 0, 'http://localhost/wp.local/wp-content/uploads/2022/07/OS0002_1140x400Px_for_Chelyabinsk_nov21.jpg', 0, 'attachment', 'image/jpeg', 0),
(25, 1, '2022-07-06 11:07:48', '2022-07-06 08:07:48', '', 'd3Ycun8SIRM1VGiTHNMlGK8JSxPf5fnUzBsh3lR6', '', 'inherit', 'open', 'closed', '', 'd3ycun8sirm1vgithnmlgk8jsxpf5fnuzbsh3lr6', '', '', '2022-07-06 11:07:48', '2022-07-06 08:07:48', '', 0, 'http://localhost/wp.local/wp-content/uploads/2022/07/d3Ycun8SIRM1VGiTHNMlGK8JSxPf5fnUzBsh3lR6.jpg', 0, 'attachment', 'image/jpeg', 0),
(26, 1, '2022-07-06 11:10:41', '2022-07-06 08:10:41', '', 'scrollable_banner_image_two', '', 'inherit', 'open', 'closed', '', 'scrollable_banner_image_two', '', '', '2022-07-06 11:10:41', '2022-07-06 08:10:41', '', 0, 'http://localhost/wp.local/wp-content/uploads/2022/07/scrollable_banner_image_two.jpg', 0, 'attachment', 'image/jpeg', 0),
(27, 1, '2022-07-06 11:13:35', '2022-07-06 08:13:35', '', 'ц1', '', 'inherit', 'open', 'closed', '', '%d1%861', '', '', '2022-07-06 11:13:35', '2022-07-06 08:13:35', '', 0, 'http://localhost/wp.local/wp-content/uploads/2022/07/ц1.png', 0, 'attachment', 'image/png', 0),
(28, 1, '2022-07-06 11:13:47', '2022-07-06 08:13:47', '', 'ц3', '', 'inherit', 'open', 'closed', '', '%d1%863', '', '', '2022-07-06 11:13:47', '2022-07-06 08:13:47', '', 0, 'http://localhost/wp.local/wp-content/uploads/2022/07/ц3.jpg', 0, 'attachment', 'image/jpeg', 0),
(29, 1, '2022-07-06 11:13:56', '2022-07-06 08:13:56', '', 'ц4', '', 'inherit', 'open', 'closed', '', '%d1%864', '', '', '2022-07-06 11:13:56', '2022-07-06 08:13:56', '', 0, 'http://localhost/wp.local/wp-content/uploads/2022/07/ц4.png', 0, 'attachment', 'image/png', 0),
(30, 1, '2022-07-06 11:14:07', '2022-07-06 08:14:07', '', 'ц5', '', 'inherit', 'open', 'closed', '', '%d1%865', '', '', '2022-07-06 11:14:07', '2022-07-06 08:14:07', '', 0, 'http://localhost/wp.local/wp-content/uploads/2022/07/ц5.jpg', 0, 'attachment', 'image/jpeg', 0),
(31, 1, '2022-07-06 11:14:17', '2022-07-06 08:14:17', '', 'ц6', '', 'inherit', 'open', 'closed', '', '%d1%866', '', '', '2022-07-06 11:14:17', '2022-07-06 08:14:17', '', 0, 'http://localhost/wp.local/wp-content/uploads/2022/07/ц6.jpg', 0, 'attachment', 'image/jpeg', 0),
(32, 1, '2022-07-06 11:26:23', '2022-07-06 08:26:23', '{"ecommerce-goldly::goldly_twitter_link":{"value":"https:\\/\\/vk.com\\/x4trid","type":"theme_mod","user_id":1,"date_modified_gmt":"2022-07-06 08:26:23"}}', '', '', 'trash', 'closed', 'closed', '', 'cbae9562-4459-414a-a61a-20537df37a8d', '', '', '2022-07-06 11:26:23', '2022-07-06 08:26:23', '', 0, 'http://localhost/wp.local/?p=32', 0, 'customize_changeset', '', 0),
(33, 1, '2022-07-06 11:26:48', '2022-07-06 08:26:48', '{"ecommerce-goldly::goldly_twitter_link":{"value":"https:\\/\\/twitter.com\\/","type":"theme_mod","user_id":1,"date_modified_gmt":"2022-07-06 08:26:48"}}', '', '', 'trash', 'closed', 'closed', '', '7cf12b43-a7e5-4a68-a7c3-347aff156a70', '', '', '2022-07-06 11:26:48', '2022-07-06 08:26:48', '', 0, 'http://localhost/wp.local/?p=33', 0, 'customize_changeset', '', 0) ;

#
# End of data contents of table `wp_posts`
# --------------------------------------------------------



#
# Delete any existing table `wp_term_relationships`
#

DROP TABLE IF EXISTS `wp_term_relationships`;


#
# Table structure of table `wp_term_relationships`
#

CREATE TABLE `wp_term_relationships` (
  `object_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_order` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_term_relationships`
#
INSERT INTO `wp_term_relationships` ( `object_id`, `term_taxonomy_id`, `term_order`) VALUES
(1, 1, 0),
(5, 2, 0),
(10, 1, 0) ;

#
# End of data contents of table `wp_term_relationships`
# --------------------------------------------------------



#
# Delete any existing table `wp_term_taxonomy`
#

DROP TABLE IF EXISTS `wp_term_taxonomy`;


#
# Table structure of table `wp_term_taxonomy`
#

CREATE TABLE `wp_term_taxonomy` (
  `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `description` longtext COLLATE utf8mb4_unicode_520_ci NOT NULL,
  `parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_term_taxonomy`
#
INSERT INTO `wp_term_taxonomy` ( `term_taxonomy_id`, `term_id`, `taxonomy`, `description`, `parent`, `count`) VALUES
(1, 1, 'category', '', 0, 2),
(2, 2, 'wp_theme', '', 0, 1) ;

#
# End of data contents of table `wp_term_taxonomy`
# --------------------------------------------------------



#
# Delete any existing table `wp_termmeta`
#

DROP TABLE IF EXISTS `wp_termmeta`;


#
# Table structure of table `wp_termmeta`
#

CREATE TABLE `wp_termmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`meta_id`),
  KEY `term_id` (`term_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_termmeta`
#

#
# End of data contents of table `wp_termmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_terms`
#

DROP TABLE IF EXISTS `wp_terms`;


#
# Table structure of table `wp_terms`
#

CREATE TABLE `wp_terms` (
  `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `slug` varchar(200) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_id`),
  KEY `slug` (`slug`(191)),
  KEY `name` (`name`(191))
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_terms`
#
INSERT INTO `wp_terms` ( `term_id`, `name`, `slug`, `term_group`) VALUES
(1, 'Без рубрики', '%d0%b1%d0%b5%d0%b7-%d1%80%d1%83%d0%b1%d1%80%d0%b8%d0%ba%d0%b8', 0),
(2, 'twentytwentytwo', 'twentytwentytwo', 0) ;

#
# End of data contents of table `wp_terms`
# --------------------------------------------------------



#
# Delete any existing table `wp_usermeta`
#

DROP TABLE IF EXISTS `wp_usermeta`;


#
# Table structure of table `wp_usermeta`
#

CREATE TABLE `wp_usermeta` (
  `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_520_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_520_ci,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_usermeta`
#
INSERT INTO `wp_usermeta` ( `umeta_id`, `user_id`, `meta_key`, `meta_value`) VALUES
(1, 1, 'nickname', 'admin'),
(2, 1, 'first_name', ''),
(3, 1, 'last_name', ''),
(4, 1, 'description', ''),
(5, 1, 'rich_editing', 'true'),
(6, 1, 'syntax_highlighting', 'true'),
(7, 1, 'comment_shortcuts', 'false'),
(8, 1, 'admin_color', 'fresh'),
(9, 1, 'use_ssl', '0'),
(10, 1, 'show_admin_bar_front', 'true'),
(11, 1, 'locale', ''),
(12, 1, 'wp_capabilities', 'a:1:{s:13:"administrator";b:1;}'),
(13, 1, 'wp_user_level', '10'),
(14, 1, 'dismissed_wp_pointers', ''),
(15, 1, 'show_welcome_panel', '1'),
(16, 1, 'session_tokens', 'a:1:{s:64:"d56ebb54a1fc745dfaf38cdf0e6bf764c9dce9df2e42bc7bdc930bd6a194f973";a:4:{s:10:"expiration";i:1658296363;s:2:"ip";s:3:"::1";s:2:"ua";s:111:"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.0.0 Safari/537.36";s:5:"login";i:1657086763;}}'),
(17, 1, 'wp_dashboard_quick_press_last_post_id', '4'),
(18, 1, 'wp_user-settings', 'libraryContent=browse'),
(19, 1, 'wp_user-settings-time', '1657095957') ;

#
# End of data contents of table `wp_usermeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_users`
#

DROP TABLE IF EXISTS `wp_users`;


#
# Table structure of table `wp_users`
#

CREATE TABLE `wp_users` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_login` varchar(60) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_pass` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_nicename` varchar(50) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_email` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_url` varchar(100) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(255) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT '0',
  `display_name` varchar(250) COLLATE utf8mb4_unicode_520_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`),
  KEY `user_login_key` (`user_login`),
  KEY `user_nicename` (`user_nicename`),
  KEY `user_email` (`user_email`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_users`
#
INSERT INTO `wp_users` ( `ID`, `user_login`, `user_pass`, `user_nicename`, `user_email`, `user_url`, `user_registered`, `user_activation_key`, `user_status`, `display_name`) VALUES
(1, 'admin', '$P$BWyvvegQVK.WtcMyfT4zils1B/OaZz/', 'admin', '20300675@live.inueco.ru', 'http://localhost/wp.local', '2022-07-06 05:52:02', '', 0, 'admin') ;

#
# End of data contents of table `wp_users`
# --------------------------------------------------------

#
# Add constraints back in and apply any alter data queries.
#

